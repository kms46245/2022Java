package ch07.ex07.case04;

public class Main_R {
	public static void main(String[] args) {
		Shooter_R shooter = new Shooter_R();
		Smith_R smith = new Smith_R();
		
		shooter.fire(() -> System.out.println("����"));
		shooter.fire(smith.makeGun());
	}

}
