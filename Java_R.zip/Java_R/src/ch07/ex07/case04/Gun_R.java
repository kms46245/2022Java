package ch07.ex07.case04;

@FunctionalInterface
public interface Gun_R {
	void fire();
}
