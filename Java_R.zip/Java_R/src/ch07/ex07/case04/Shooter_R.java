package ch07.ex07.case04;

public class Shooter_R {
	public void fire(Gun_R gun) {
		gun.fire();
	}
}
