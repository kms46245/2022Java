package ch07.ex07.case04;

public class Smith_R {
	public Gun_R makeGun() {
		return () -> System.out.println("�帣��");
	}
}
