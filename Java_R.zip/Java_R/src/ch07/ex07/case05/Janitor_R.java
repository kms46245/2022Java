package ch07.ex07.case05;

@FunctionalInterface
public interface Janitor_R<T> {
	void clean(T t);
}
