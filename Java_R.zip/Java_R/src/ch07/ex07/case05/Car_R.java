package ch07.ex07.case05;

public class Car_R {
	@Override
	public String toString() {
		return "��";
	}
}
