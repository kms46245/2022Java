package ch07.ex07.case05;

public class Main_R {

	public static void main(String[] args) {
		Janitor_R<Buliding_R> janitor1 = a ->
			System.out.println(a + ", û���մϴ�.");
		Janitor_R<Car_R> janitor2 = b ->
			System.out.println(b + ", û���մϴ�.");
			
		janitor1.clean(new Buliding_R());
		janitor2.clean(new Car_R());
	}

}
