package ch07.ex07.case05;

public class Buliding_R {
	@Override
	public String toString() {
		return "����";
	}
	
}
