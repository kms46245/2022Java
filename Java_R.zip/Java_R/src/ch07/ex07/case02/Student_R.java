package ch07.ex07.case02;

public class Student_R implements Human_R{
	@Override
	public void say() {
		System.out.println("Student say");
	}
}
