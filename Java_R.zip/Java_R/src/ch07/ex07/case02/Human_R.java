package ch07.ex07.case02;

@FunctionalInterface
public interface Human_R {
	void say();
	
	static void walk() {
		System.out.println("Human walk");
	}
	
	default void sleep() {
		System.out.println("Human Sleep");
	}
}
