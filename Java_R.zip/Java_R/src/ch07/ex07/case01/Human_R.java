package ch07.ex07.case01;

@FunctionalInterface
public interface Human_R {
	void say();
}
