package ch07.ex07.case01;

public class Main_R {

	public static void main(String[] args) {
		Human_R human = () -> System.out.println("hello");
		human.say();
	}

}
