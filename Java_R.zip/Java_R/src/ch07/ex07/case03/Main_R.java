package ch07.ex07.case03;

public class Main_R {

	public static void main(String[] args) {
		Calc_R calc = (int x, int y) ->{
			int result = x + y;
			return result;
		};	// ����
		
		calc = (a, b) -> a + b; // ����(���־�)
		
		System.out.println(calc.Calc(1,2));
	}

}
