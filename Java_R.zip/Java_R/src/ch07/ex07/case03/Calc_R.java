package ch07.ex07.case03;

@FunctionalInterface
public interface Calc_R {
	int Calc(int x, int y);
}
