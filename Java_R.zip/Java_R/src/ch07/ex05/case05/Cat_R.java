package ch07.ex05.case05;

public class Cat_R {
	private String name;
	
	public Cat_R(String name) {
		this.name = name;
	}
	
	public void eat() {
		System.out.println(this.name + ", �Դ�.");
	}
	
	@Override
	public String toString() {
		return this.name;
	}
}
