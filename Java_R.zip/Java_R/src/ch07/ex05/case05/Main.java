package ch07.ex05.case05;

import java.util.ArrayList;
import java.util.List;

public class Main {
	public static void main(String[] args) {
		List<Cat_R> cats = new ArrayList<Cat_R>();
		
		cats.add(new Cat_R("���ڹ�"));
		cats.add(new Cat_R("���ڹ�"));
		cats.add(new Cat_R("�����"));
		
		System.out.println(cats);
		
		for(Cat_R cat: cats) cat.eat();
	}
}
