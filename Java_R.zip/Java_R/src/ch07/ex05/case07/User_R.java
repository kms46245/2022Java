package ch07.ex05.case07;

public class User_R {
	private String name;
	
	public User_R(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.name;
	}
}
