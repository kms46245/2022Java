package ch07.ex05.case01;

public class Apple_R {
	@Override
	public String toString() {
		return "���";
	}
}
