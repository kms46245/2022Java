package ch07.ex05.case01;

public class Grape_R {
	@Override
	public String toString() {
		return "����";
	}
}
