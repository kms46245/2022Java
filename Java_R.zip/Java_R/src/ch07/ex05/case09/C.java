package ch07.ex05.case09;

public class C extends B implements A{

}
