package ch07.ex05.case09;

public interface A {
	
}
