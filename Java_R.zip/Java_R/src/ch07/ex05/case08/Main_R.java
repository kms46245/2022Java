package ch07.ex05.case08;

import java.util.ArrayList;
import java.util.List;

public class Main_R {
	public static void main(String[] args) {
		Dove_R dove = new Dove_R();
		Duck_R duck = new Duck_R();
		Lion_R lion = new Lion_R();
		Leopard_R leopard = new Leopard_R();
		
		List<Creeper_R> pen = new ArrayList<>();
		pen.add(lion);
		pen.add(leopard);
		//pen.add(dove); ��ӹ޴� Ÿ���� ��ü�� ����
		
		List<Bird_R> cage = new ArrayList<>();
		cage.add(dove);
		cage.add(duck);
		//cage.add(lion)
		
		for(Creeper_R creeper : pen) creeper.walk();
		for(Bird_R bird : cage) bird.fly();
	}
}
