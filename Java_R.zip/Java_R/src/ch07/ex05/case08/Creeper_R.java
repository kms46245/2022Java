package ch07.ex05.case08;

public interface Creeper_R {
	void walk();
}
