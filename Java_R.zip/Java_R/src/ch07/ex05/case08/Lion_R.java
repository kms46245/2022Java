package ch07.ex05.case08;

public class Lion_R implements Creeper_R{
	@Override
	public void walk() {
		System.out.println("���ڰ� �ȴ´�.");
	}
}
