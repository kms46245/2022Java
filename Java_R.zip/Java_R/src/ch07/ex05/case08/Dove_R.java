package ch07.ex05.case08;

public class Dove_R implements Bird_R{
	@Override
	public void fly() {
		System.out.println("��ѱⰡ ����.");
	}
	
}
