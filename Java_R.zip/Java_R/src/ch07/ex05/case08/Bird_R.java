package ch07.ex05.case08;

public interface Bird_R {
	void fly();
}
