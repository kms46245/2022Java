package ch07.ex05.case10;

public interface Autobot_R {
	void run();
	void fight();
}
