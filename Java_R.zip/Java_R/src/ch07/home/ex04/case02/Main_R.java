package ch07.home.ex04.case02;

public class Main_R {
	public static void main(String[] args) {
		Card_R[] cards = new Card_R[5];
		
		for(int i = 0; i < cards.length; i++)
			cards[i] = new Card_R(i);
		
		for(Card_R card : cards) System.out.print(card + " ");
		
		System.out.println();
		
		for(int i = 0; i < 100; i++) {
			int index = (int)(Math.random() * 4) + 1;
			
			Card_R tmp = cards[0];
			cards[0] = cards[index];
			cards[index] = tmp;
		}
		
		for(Card_R card: cards) System.out.print(card + " ");
	}
}

// ch07.ex04.case02.Shuffle�� OOP�� refactoring�϶�.