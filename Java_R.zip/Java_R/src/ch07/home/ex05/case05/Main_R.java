package ch07.home.ex05.case05;

import java.util.ArrayList;
import java.util.List;

public class Main_R {
	public static void main(String[] args) {
		Slot_R slot = new Slot_R();
		List<Ball_R> balls = new ArrayList<>();
		
		for(int i = 0; i < 6; i++)
			balls.add(slot.Chuck());
		
		for(Ball_R ball: balls)
			System.out.print(ball + " ");
	}
}

// ch07.ex04.case04�� list�� refactoring �϶�.