package ch07.home.ex05.case05;

public class Ball_R {
	private int num;
	
	public Ball_R(int num) {
		this.num = num;
	}
	
	@Override
	public String toString() {
		return this.num + "";
	}
}
