package ch07.home.ex05.case10;

public interface Stationary_R {

}
