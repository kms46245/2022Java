package ch07.home.ex05.case10;

public class Eraser_R implements Stationary_R{
	public void Erase() {
		System.out.println("�����.");
	}
}
