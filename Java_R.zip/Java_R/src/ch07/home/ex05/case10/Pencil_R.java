package ch07.home.ex05.case10;

public class Pencil_R implements Stationary_R{
	public void write() {
		System.out.println("�ʱ��ϴ�.");
	}
}
