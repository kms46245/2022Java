package ch07.home.ex05.case10;

import java.util.ArrayList;

public class Bag_R<E> extends ArrayList<E> {
	
}
