package ch07.ex06.case05;

public class Box_R { // generic method
	public<T> T getLastVal(T[] arr) {
		return arr[arr.length -1];
	}
}
