package ch07.ex06.case06;

public class D extends C{

}
