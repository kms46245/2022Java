package ch07.ex06.case04;

public class Main_R {
	public static void main(String[] args) {
		Bowl_R<Integer> bowl1 = new Bowl_R<>();
		Bowl_R<String> bowl2 = new Bowl_R<>();
		
		bowl1.setVal(1);
		bowl2.setVal("hello");
		
		int i = bowl1.getVal();
		String s = bowl2.getVal();
	}
}
