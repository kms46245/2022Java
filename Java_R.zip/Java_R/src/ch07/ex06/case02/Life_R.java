package ch07.ex06.case02;

public class Life_R {
	public static void eat() {
		System.out.println("�Դ�.");
	}
	
	public void shout() {
		System.out.println("�Ҹ�ġ��.");
	}
}
