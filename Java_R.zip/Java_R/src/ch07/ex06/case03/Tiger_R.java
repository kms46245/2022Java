package ch07.ex06.case03;

public class Tiger_R implements Animal_R{
	@Override
	public void move() {
		System.out.println("�޸���.");
	}
}
