package ch07.ex06.case03;

public interface Animal_R {
	default void eat() {
		System.out.println("�Դ�.");
	}
	
	void move();
}
