package ch07.ex06.case03;

public class Cosmos_R {
	public static Animal_R getAnimal(String animalName) { // factory method
		Animal_R animal = null;
		
		switch(animalName) {
		case "ȣ����": animal = new Tiger_R(); break;
		case "��": animal = new Falcon_R();
		}
		return animal;
	}
}
