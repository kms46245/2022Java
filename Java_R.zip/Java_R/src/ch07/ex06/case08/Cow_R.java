package ch07.ex06.case08;

public class Cow_R {

}
