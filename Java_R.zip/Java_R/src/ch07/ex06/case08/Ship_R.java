package ch07.ex06.case08;

import java.util.ArrayList;
import java.util.List;

public class Ship_R {
	private List<Container_R<?>> containers;
	
	public Ship_R() {
		containers = new ArrayList<>();
	}
	
	public void put(Container_R<?> container) {
		containers.add(container);
	}
}
