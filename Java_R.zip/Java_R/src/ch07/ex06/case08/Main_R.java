package ch07.ex06.case08;

public class Main_R {
	public static void main(String[] args) {
		Ship_R ship = new Ship_R();
		Container_R<Cow_R> container1 = new Container_R<>();
		Container_R<Car_R> container2 = new Container_R<>();
		
		ship.put(container1);
		ship.put(container2);
 	}

}
