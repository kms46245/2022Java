package ch07.ex06.case08;

import java.util.ArrayList;

public class Container_R<E> extends ArrayList<E> {
	public void contain(E things) {
		this.add(things);
	}
}
