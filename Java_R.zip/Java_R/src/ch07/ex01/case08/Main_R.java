package ch07.ex01.case08;

public class Main_R {
	public static void main(String[] args) {
		Clerk_R clerk = new Clerk_R();
		System.out.println(clerk.sell("���"));
	}
	
}
