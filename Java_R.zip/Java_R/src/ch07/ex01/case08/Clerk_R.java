package ch07.ex01.case08;

public class Clerk_R {
	public Flower_R sell(String flowerName) {
		Flower_R flower = null;
		
		switch(flowerName) {
		case "����": flower = new Lily_R(); break;
		case "���": flower = new Rose_R();
		}
		
		return flower;
	}
}
