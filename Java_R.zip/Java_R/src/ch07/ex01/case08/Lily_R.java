package ch07.ex01.case08;

public class Lily_R implements Flower_R{
	@Override
	public String toString() {
		return "����";
	}
}
