package ch07.ex01.case08;

public interface Flower_R {

}
