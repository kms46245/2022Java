package ch07.ex01.case01;

public interface B {

}
