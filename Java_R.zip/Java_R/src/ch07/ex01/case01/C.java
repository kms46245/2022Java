package ch07.ex01.case01;

public class C implements A, B{

}
