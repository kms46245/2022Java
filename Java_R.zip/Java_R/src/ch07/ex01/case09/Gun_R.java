package ch07.ex01.case09;

public interface Gun_R {
	void fire();
}
