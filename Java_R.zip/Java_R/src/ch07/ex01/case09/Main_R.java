package ch07.ex01.case09;

public class Main_R {
	public static void main(String[] args) {
		Pistol_R pistol = new Pistol_R();
		Rifle_R rifle = new Rifle_R();
		Shooter_R shooter = new Shooter_R();
		
		shooter.setGun(pistol);
		shooter.fire();
		
		shooter.setGun(rifle);
		shooter.fire();
		
	}
}
