package ch07.ex01.case04;

public interface Tree_R {
	
}
