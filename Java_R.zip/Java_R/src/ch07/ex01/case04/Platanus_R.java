package ch07.ex01.case04;

public class Platanus_R implements Tree_R {

}
