package ch07.ex01.case05;

public class Car_R {
	public void run() {
		
	}
}
