package ch07.ex01.case05;

public class FireEngine_R extends Car_R{
	public void water() {
		
	}
}
