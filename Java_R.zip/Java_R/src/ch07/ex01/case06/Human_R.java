package ch07.ex01.case06;

public class Human_R {
	public void Sleep() {
		
	}
}
