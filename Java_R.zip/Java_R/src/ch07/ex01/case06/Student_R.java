package ch07.ex01.case06;

public class Student_R extends Human_R{
	public void study() {
		
	}
}
