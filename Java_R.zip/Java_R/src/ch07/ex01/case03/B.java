package ch07.ex01.case03;

public interface B {

}
