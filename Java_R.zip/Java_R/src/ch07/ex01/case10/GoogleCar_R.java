package ch07.ex01.case10;

public class GoogleCar_R implements _AICar{
	@Override
	public void start() {
		System.out.println("Google Start.");
	}
}
