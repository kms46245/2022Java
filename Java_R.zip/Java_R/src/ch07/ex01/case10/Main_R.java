package ch07.ex01.case10;

public class Main_R {
	public static void main(String[] args) {
		AppleCar_R appleCar = new AppleCar_R();
		GoogleCar_R googleCar = new GoogleCar_R();
		TeslaCar_R teslaCar = new TeslaCar_R();
		
		teslaCar.setOS(appleCar);
		teslaCar.setOS(googleCar);
		
		teslaCar.start();
	}
}
