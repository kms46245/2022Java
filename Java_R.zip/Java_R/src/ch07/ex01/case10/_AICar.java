package ch07.ex01.case10;

public interface _AICar {
	void start();
}
