package ch07.ex01.case10;

public class TeslaCar_R implements _AICar{
	private _AICar os;
	
	@Override
	public void start() {
		os.start();
	}
	
	public void setOS(_AICar aiCar) {
		this.os = aiCar;
	}
}
