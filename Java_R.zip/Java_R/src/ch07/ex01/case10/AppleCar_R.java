package ch07.ex01.case10;

public class AppleCar_R implements _AICar{
	@Override
	public void start() {
		System.out.println("Apple Start.");
	}
}
