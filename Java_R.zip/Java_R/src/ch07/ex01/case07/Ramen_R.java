package ch07.ex01.case07;

public class Ramen_R implements Food_R{
	@Override
	public String toString() {
		return "���";
	}
}
