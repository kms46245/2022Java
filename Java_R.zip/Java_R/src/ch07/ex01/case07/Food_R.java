package ch07.ex01.case07;

public interface Food_R {

}
