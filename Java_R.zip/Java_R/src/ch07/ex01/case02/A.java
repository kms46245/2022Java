package ch07.ex01.case02;

public class A /*extends Object*/{

}
// root