package ch07.ex01.case02;

public class B extends A{

}
