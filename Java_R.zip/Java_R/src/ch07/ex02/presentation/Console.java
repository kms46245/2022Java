package ch07.ex02.presentation;

public interface Console {
	static void info(Object obj) {
		System.out.println(obj);
	}
}
