package ch07.ex02.service;

import ch07.ex02.domain.User;

public interface UserService {
	public User getUser();
}
