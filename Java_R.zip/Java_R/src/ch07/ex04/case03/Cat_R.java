package ch07.ex04.case03;

public class Cat_R {
	private String name;
	
	public Cat_R(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.name;
	}
}
