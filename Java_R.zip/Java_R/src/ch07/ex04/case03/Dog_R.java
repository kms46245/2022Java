package ch07.ex04.case03;

public class Dog_R {

}
