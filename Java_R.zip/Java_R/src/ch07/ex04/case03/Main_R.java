package ch07.ex04.case03;

public class Main_R {
	public static void main(String[] args) {
		Cat_R[] cats = new Cat_R[3];
		
		cats[0] = new Cat_R("�߿���");
		cats[1] = new Cat_R("�ֿ���");
		cats[2] = new Cat_R("������");
		
		for	(Cat_R cat : cats) System.out.println(cat);
	}
}
