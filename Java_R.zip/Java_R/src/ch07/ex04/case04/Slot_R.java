package ch07.ex04.case04;

public class Slot_R {
	private Ball_R[] balls;
	
	public Slot_R() {
		balls = new Ball_R[45];
		
		for(int i = 0; i < balls.length; i++)
			balls[i] = new Ball_R(i + 1);
	}

	public Ball_R chuck() {
		int i = 0;
		Ball_R ball = null;
		
		do {
			i = (int)(Math.random()* 45);
			ball = balls[i];
			balls[i] = null;			
		}while(ball == null);
		
		return ball;
	}
}
