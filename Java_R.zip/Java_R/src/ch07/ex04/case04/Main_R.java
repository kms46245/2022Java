package ch07.ex04.case04;

public class Main_R {
	public static  void main(String[] args) {
		Slot_R slot = new Slot_R();
		Ball_R[] balls = new Ball_R[6];
		
		for(int i = 0; i < 6; i++) {
			balls[i] = slot.chuck();
		}
		
		for(Ball_R ball: balls)
			System.out.print(ball.getNum() + " ");
	}
}
