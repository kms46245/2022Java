package ch07.ex04.case04;

public class Ball_R {
	private int num;
	
	public Ball_R(int num) {
		this.num = num;
	}
	
	public int getNum() {
		return num;
	}
}
