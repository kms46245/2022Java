package ch07.ex04.case06;

public class Main_R {
	public static void main(String[] args) {
		Animal_R[] animals = new Animal_R[3];
		
		animals[0] = new Cat_R("����");
		animals[1] = new Dog_R("�ʺ�");
		animals[2] = new Dog_R("����");
		
		for(Animal_R animal: animals)
			System.out.println(animal);
		
		Object[] objs = new Object[3];
		objs[0] = new Cat_R("�߿���");
		objs[1] = new Dog_R("�۸���");
		objs[2] = new Dog_R("�տ���");
		
		for(Object obj: objs)
			System.out.println(obj);
	}
}
