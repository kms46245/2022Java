package ch07.ex04.case06;

public class Dog_R implements Animal_R{
	private String name;
	
	public Dog_R(String name) {
		this.name = name;
	}
	
	@Override
	public String toString() {
		return this.name;
	}
}
