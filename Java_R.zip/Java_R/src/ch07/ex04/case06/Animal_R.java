package ch07.ex04.case06;

public interface Animal_R {

}
