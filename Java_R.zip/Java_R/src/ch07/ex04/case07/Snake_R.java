package ch07.ex04.case07;

public class Snake_R implements Animal_R{
	@Override
	public void eat() {
		System.out.println("�ܲ��ϴ�.");
	}
}
