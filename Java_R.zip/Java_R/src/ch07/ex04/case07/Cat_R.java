package ch07.ex04.case07;

public class Cat_R implements Animal_R{
	@Override
	public void eat() {
		System.out.println("�ô�.");
	}
}
