package ch07.ex04.case07;

public interface Animal_R {
	public void eat();
}
