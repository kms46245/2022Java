package ch07.ex04.case07;

public class Main_R {
	public static void main(String[] args) {
		Animal_R[] animals = new Animal_R[3];
		
		animals[0] = new Cat_R();
		animals[1] = new Snake_R();
		animals[2] = new Snake_R();
		
		for(Animal_R animal: animals)
			animal.eat();
	}
}
