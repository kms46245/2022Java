package ch07.ex04.case02;

public class Shuffle_R {
	public static void main(String[] args) {
		int[] cards = new int[5];
		
		for(int i = 0; i < cards.length; i++)
			cards[i] = i;
		
		for(int i : cards)
			System.out.print(i + " ");
		System.out.println();
		
		for(int i = 0; i < 100; i++) {
			int index = (int)(Math.random() * (cards.length - 1) + 1);
			
			int temp = cards[0];
			cards[0] = cards[index];
			cards[index] = temp;
		}
		for(int i: cards) System.out.print(i + " ");
	}
}
