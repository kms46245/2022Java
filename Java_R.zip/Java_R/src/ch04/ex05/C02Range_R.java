package ch04.ex05;

public class C02Range_R {
	public static void main(String[] args) {
		int sum = 0;
		
		for	(int i = 1; i <= 10; i++) {
			sum += 1;
		}
		
		System.out.println(sum);
	}
}
