package ch04.home.ex04;

import java.util.Scanner;

public class H01_01Mine {

	public static void main(String[] args) {
		 Scanner sc = new Scanner(System.in);
		 String input = "";
		 boolean isGood = false;
		 String oneErrMsg = "1�� �ڸ� �ڿ����� �Է����ּ���.\n";
		 String noneErrMsg = "���� �Է����ּ���.\n";
		  
		  do {
			  System.out.print("�Է�: ");
			  input = sc.nextLine();
			  if(input.length() != 0) {
				  if(input.length() == 1  && '0' <= input.charAt(0) && input.charAt(0) <= '9' )
					  isGood = true;
				  else
					  System.out.printf(oneErrMsg);
			  }
			  else  System.out.print(noneErrMsg);
			  } while(!isGood);
		  
		  System.out.print("��.");	
	}
}
