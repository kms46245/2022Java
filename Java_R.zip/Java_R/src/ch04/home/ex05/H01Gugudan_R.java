package ch04.home.ex05;

public class H01Gugudan_R {
	public static void main(String[] args) {
		int i = 0, j = 0, res = 0;
		
		for	(i = 2; i <= 9; i++) {
			for(j = 1; j <= 9; j++) {
			res = i * j;
			System.out.printf("%d * %d = %d\n", i, j, res);
			}
		System.out.println("----------");
		}
	}
}
