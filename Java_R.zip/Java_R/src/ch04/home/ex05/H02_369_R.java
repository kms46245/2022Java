package ch04.home.ex05;

public class H02_369_R {
	public static void main(String[] args) {
		int oneDigit = 0, tenDigit = 0;
		String oneClap = "", tenClap = "";
		  
		for(tenDigit = 0; tenDigit < 10; tenDigit++){
			for(oneDigit = 0; oneDigit < 10; oneDigit++){
				if(oneDigit % 3 == 0 && oneDigit != 0)
					oneClap = "¦"; else oneClap = "";
				if(tenDigit % 3 == 0 && tenDigit != 0)
					tenClap = "¦"; else tenClap = "";
				
				if(tenDigit == 0 && oneDigit == 0) // 0�϶�
					System.out.print("");
				else if(tenDigit == 0 && oneDigit > 0) // ���ڸ���
					System.out.printf("%d%s ", oneDigit, oneClap);
				else System.out.printf("%d%d%s%s ",tenDigit, oneDigit, tenClap, oneClap);
			}
		  System.out.println("\n-----------------------------------------------"); 
		}
	}
}

