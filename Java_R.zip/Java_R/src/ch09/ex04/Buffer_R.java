package ch09.ex04;

public class Buffer_R {

}
