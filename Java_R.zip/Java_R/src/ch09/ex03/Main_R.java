package ch09.ex03;

public class Main_R {
	public static void main(String[] args) {
		Counter_R counter = new Counter_R();
		new Player_R(counter).start();
		new Player_R(counter).start();
		new Player_R(counter).start();
		new Player_R(counter).start();
		new Player_R(counter).start();
		new Player_R(counter).start();
		new Player_R(counter).start();
	}
}
