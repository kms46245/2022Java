package ch05.ex07.case02;

public class Main_R {
	public static void main(String[] args) {
		System.out.println("Stack.main() ����.");
		int a = 0;
		Stack_R.first();
		System.out.println("��.");
		System.out.println("Stack.main() ��.");
	}
}
