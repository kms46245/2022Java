package ch05.ex07.case01;

public class Stack_R {
	public static void first() {
		int a = 0;
		Stack_R.second();
	}
	
	public static void second() {
		int a = 0;
	}
}
