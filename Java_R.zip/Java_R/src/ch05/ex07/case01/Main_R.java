package ch05.ex07.case01;

public class Main_R {
	public static void main(String[] args) {
		int a = 0;
		Stack_R.first();
		System.out.println("��.");
	}
}
