package ch05.ex04.case02;

public class Player_R {
	public String name;
	public static String teamName;
	
	public String getName() {
		return name;
	}
	
	public static String getTeamName() {
		return teamName;
	}

	public void setName(String name) {
		this.name = name;
	}

	public static void setTeamName(String teamName) {
		Player_R.teamName = teamName;
	}
}
