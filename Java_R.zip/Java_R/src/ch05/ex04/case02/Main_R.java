package ch05.ex04.case02;

public class Main_R {
	public static void main(String[] args) {
		Player_R.teamName = "lions";
		
		Player_R player1 = new Player_R();
		Player_R player2 = new Player_R();
		
		player1.setName("���Ѽ�");
		player2.setName("�ѾƸ�");
		
		System.out.printf("%s, %s\n",player1.getName(),player1.getTeamName());
		System.out.printf("%s, %s\n",player1.getName(),Player_R.getTeamName());
		System.out.printf("%s, %s\n",player2.getName(),player2.getTeamName());
	}
}
