package ch05.ex04.case01;

public class Card_R {
	public String kind;
	public int number;
	public static int width;
	public static int height;
}
