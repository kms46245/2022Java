package ch05.home.ex05.case06;

public class User_R {
	private String name;
	private Phone_R phone;
	
	public void sendMsg() {
		phone.sendMsg();
	}
	
	public void Call() {
		phone.Call();
	}
	
	public void playGame() {
		phone.playGame();
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setPhone(Phone_R phone) {
		this.phone = phone;
	}
}
