package ch05.home.ex05.case06;

public class Main_R {
	public static void main(String[] args) {
		Phone_R phone = new Phone_R();
		User_R user = new User_R();
		
		phone.setBrand("�Ｚ");
		phone.setPrice(1_000_000);
		
		user.setName("���Ѽ�");
		user.setPhone(phone);
		
		user.sendMsg();
		user.Call();
		user.playGame();
	}
}
