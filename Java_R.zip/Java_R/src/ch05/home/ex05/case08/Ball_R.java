package ch05.home.ex05.case08;

public class Ball_R {

}
