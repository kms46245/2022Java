package ch05.home.ex05.case08;

public class Main_R {
	public static void main(String[] args) {
		Man_R man1 = new Man_R();
		Man_R man2 = new Man_R();
		Man_R man3 = new Man_R();
		Ball_R ball = new Ball_R();
		
		man1.setName("���Ѽ�");
		man2.setName("�ѾƸ�");
		man3.setName("�����");
		
		man3.pass(man2.pass(man1.pass(ball)));
	}
}
