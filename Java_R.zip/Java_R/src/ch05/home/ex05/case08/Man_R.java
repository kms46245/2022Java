package ch05.home.ex05.case08;

public class Man_R {
	private String name;
	
	public Ball_R pass(Ball_R ball) {
		return ball;
	}
	
	public Ball_R kick(Ball_R ball) {
		return ball;
	}

	public void setName(String name) {
		this.name = name;
	}
}
