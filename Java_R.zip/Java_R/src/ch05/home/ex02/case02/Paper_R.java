package ch05.home.ex02.case02;

public class Paper_R {
	private String msg;
	private String writerName;
	
	public String getMsg() {
		return msg;
	}
	
	public String getWriterName() {
		return writerName;
	}
	
	public void setMsg(String msg) {
		this.msg = msg;
	}
	
	public void setWriterName(String writerName) {
		this.writerName = writerName;
	}	
}
