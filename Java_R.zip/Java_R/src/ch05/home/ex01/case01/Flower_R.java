package ch05.home.ex01.case01;

public class Flower_R {
	String name;
	int petal;
	int calyx;
}
