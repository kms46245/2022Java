package ch05.ex09.case02;

public class Main_R {
	public static void main(String[] args) {
		Phone_R phone1 = new Phone_R();
		Phone_R phone2 = new Phone_R();
		Phone_R phone3 = new Phone_R(1000);
		Phone_R phone4 = new Phone_R();
		
		System.out.printf("%d, %d, %d, %d",
				phone1.getSerial(), phone2.getSerial(),
				phone3.getSerial(), phone4.getSerial());
				
	}
}
