package ch05.ex08.case03;

public class Main_R {
	public static void main(String[] args) {
		Citrus_R citrus = new Citrus_R();
		
		System.out.println(citrus.getName());
		
		Citrus_R citrus1 = new Citrus_R();
		Citrus_R citrus2 = new Citrus_R("õ����");
		
		System.out.println(citrus1.getName());
		System.out.println(citrus2.getName());
	}
}
