package ch05.ex08.case04;

public class Main_R {
	public static void main(String[] args) {
		Deposit_R deposit = new Deposit_R();
		System.out.println(deposit.getBalance());
		
		deposit = new Deposit_R(2000, 1000);
		System.out.println(deposit.getBalance());
		
	}
}
