package ch05.ex08.case01;

public class Baby_R {
	private String name;
	
	public Baby_R() { }
	public Baby_R(String name) {
		this.name = name;
	}
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
}
