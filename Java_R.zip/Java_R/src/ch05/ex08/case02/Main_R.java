package ch05.ex08.case02;

import java.time.LocalDate;

public class Main_R {
	public static void Main(String[] args) {
		
		User_R user1 = new User_R("���Ѽ�", 25, LocalDate.now());
		User_R user2 = new User_R();
		
		user2.setName("�����");
		user2.setAge(35);
		user2.setRegDate(LocalDate.now());
		
		System.out.printf("%s %d %s\n",
				user1.getName(),user1.getAge(), user1.getRegDate());
		System.out.printf("%s %d %s\n",
				user2.getName(),user2.getAge(), user2.getRegDate());
		
	}
}
