package ch05.ex03.case02;

public class Tv_R {
	private String Color;

	public String getColor() {
		return Color;
	}

	public void setColor(String color) {
		Color = color;
	}	
}
