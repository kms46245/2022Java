package ch05.ex01.case03;

public class Main_R {
	public static void main(String[] args) {
		User_R user1 = new User_R();
		User_R user2 = new User_R();
		
		User_R user = new User_R();
		user.setName("���Ѽ�");
		user.setAge(12);
		
		System.out.printf("%s�� ���̴� %d�Դϴ�.\n", user.getName(),user.getAge());

		user.setName("�ѾƸ�");
		user.setAge(22);

		System.out.printf("%s�� ���̴� %d�Դϴ�.\n", user.getName(),user.getAge());
		
	}
}
