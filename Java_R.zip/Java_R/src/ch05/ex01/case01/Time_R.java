package ch05.ex01.case01;

public class Time_R {
	int hour;
	int minute;
	int second;
}
