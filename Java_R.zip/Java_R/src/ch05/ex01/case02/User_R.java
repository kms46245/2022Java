package ch05.ex01.case02;

public class User_R {
	String name;
	int age;
}
