package ch05.ex01.case04;

public class Main_R {

	public static void main(String[] args) {
		User_R user = new User_R();
		user.setName("���Ѽ�");
		System.out.println(user.getName());

		user.setName("�ѾƸ�");
		System.out.println(user.getName());
	}

}
