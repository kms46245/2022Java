package ch05.ex06.case01;

public class Man_R {
	public static void say(String msg) { //static method
		System.out.println(msg);
	}
	
	public void tell(String msg) {	// instance method
		System.out.println(msg);
	}
}
