package ch05.ex05.case03;

public class Paper_R {
	private int a;
	private int b;
	private int result;
	
	public int getA() {
		return a;
	}
	
	public int getB() {
		return b;
	}
	
	public int getResult() {
		return result;
	}
	
	public void setA(int a) {
		this.a = a;
	}
	
	public void setB(int b) {
		this.b = b;
	}
	
	public void setResult(int result) {
		this.result = result;
	}	
}
