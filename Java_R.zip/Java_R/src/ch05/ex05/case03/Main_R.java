package ch05.ex05.case03;

public class Main_R {
	public static void main(String[] args) {
		Calculator_R calc = new Calculator_R();
		
		int result = calc.add(1, 2);
		System.out.println(result);
		
		Paper_R paper = new Paper_R();
		paper.setA(1);
		paper.setB(2);
		paper = calc.add(paper);
		
		System.out.println(paper.getResult());
	}
}
