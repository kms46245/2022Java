package ch05.ex05.case03;

public class Calculator_R {
	public int add(int a, int b) {
		return a + b;
	}
	
	public Paper_R add(Paper_R paper) {
		paper.setResult(paper.getA() + paper.getB());
		
		return paper;
	}
}
