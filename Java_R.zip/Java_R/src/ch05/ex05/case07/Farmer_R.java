package ch05.ex05.case07;

public class Farmer_R {
	public Apple_R Sell(int price) {
		Apple_R apple = new Apple_R();
		apple.setPrice(price);
		
		return apple;
	}
}
