package ch05.ex05.case07;

public class Retailer_R {
	public Apple_R Sell(Apple_R apple) {
		apple.setPrice(apple.getPrice() * 2);
		
		return apple;
	}
}
