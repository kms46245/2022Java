package ch05.ex05.case02;

public class Calculator_R {
	public double add(int a, int b) {
		return a + b;
	}
	
	public double add(double a, double b) {
		return a + b;
	}
}
