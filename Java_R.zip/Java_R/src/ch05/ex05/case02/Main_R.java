package ch05.ex05.case02;

public class Main_R {
	public static void main(String[] args) {
		Calculator_R calc = new Calculator_R();
		
		double res = calc.add(1, 2);	// promotion
		res = calc.add(1.0, 2.0);
		
		System.out.println(res);
	}
}
