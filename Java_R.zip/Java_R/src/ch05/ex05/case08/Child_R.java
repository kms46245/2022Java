package ch05.ex05.case08;

public class Child_R {
	public void Eat(Pasta_R pasta) {
		
	}
}
