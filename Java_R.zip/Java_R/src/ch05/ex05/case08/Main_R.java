package ch05.ex05.case08;

public class Main_R {
	public static void main(String[] args) {
		Mom_R mom = new Mom_R();
		Child_R child = new Child_R();
		
		child.Eat(mom.Cook());
	}
}
