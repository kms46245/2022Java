package ch05.ex05.case08;

public class Pasta_R {

}
