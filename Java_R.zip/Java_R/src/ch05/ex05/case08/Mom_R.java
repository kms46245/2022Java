package ch05.ex05.case08;

public class Mom_R {
	public Pasta_R Cook() {
		return new Pasta_R();
	}
}
