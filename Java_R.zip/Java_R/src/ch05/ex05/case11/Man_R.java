package ch05.ex05.case11;

public class Man_R {
	public void eat(Apple_R apple) {}
	public void eat(Grape_R grape) {}
}
