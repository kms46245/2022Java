package ch05.ex05.case04;

public class Main_R {
	public static void main(String[] args) {
		Dog_R dog = new Dog_R();
		
		dog.setName("����");
		dog.setName("��Ƽ��");
		
		dog.shout();
		dog.eat();
	}
}
