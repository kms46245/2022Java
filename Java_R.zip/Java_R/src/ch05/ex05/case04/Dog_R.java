package ch05.ex05.case04;

public class Dog_R {
	private String name;
	private String breed;
	
	public void eat() {}
	public void shout() {}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public void setBreed (String breed) {
		this.breed = breed;
	}
}
