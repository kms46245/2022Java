package ch05.ex05.case01;

public class Main_R {
	public static void main(String[] args) {
		Calculator_R calc = new Calculator_R();
		
		int result = calc.add(1, 2);
		result = calc.add(1, 2, 3);
		
		System.out.println(result);
	}
}
