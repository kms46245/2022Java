package ch05.ex05.case01;

public class Calculator_R {
	public int add(int a, int b) { // transparent(����ȭ)
		return a + b;
	}
	
	public int add(int a, int b, int c) {
		return a + b + c;
	}
}
