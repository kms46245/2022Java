package ch05.ex05.case05;

public class Basket_R {
	private Apple_R apple;
	
	public Apple_R GetApple() {
		return apple;
	}
	
	public void setApple(Apple_R apple) {
		this.apple = apple;
	}
}
