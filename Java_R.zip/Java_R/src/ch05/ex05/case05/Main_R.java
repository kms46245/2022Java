package ch05.ex05.case05;

public class Main_R {
	public static void main(String[] args) {
		Apple_R apple = new Apple_R();
		Basket_R basket = new Basket_R();
		
		basket.setApple(apple);
		basket.GetApple();
	}
}
