package ch05.ex05.case06;

public class Shooter_R {
	private Gun_R gun;
	
	public void fire() {
		gun.fire();
	}
	
	public Gun_R getGun() {
		return gun;
	}
	
	public void setGun(Gun_R gun) {
		this.gun = gun;
	}
}
