package ch05.ex05.case06;

public class Main_R {
	public static void main(String[] args) {
		Gun_R gun = new Gun_R();
		Shooter_R shooter = new Shooter_R();
		
		shooter.setGun(gun);
		shooter.fire();
	}
}
