package ch05.ex05.case06;

public class Gun_R {
	public void fire() {}
}
