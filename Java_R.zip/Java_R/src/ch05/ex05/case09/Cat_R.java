package ch05.ex05.case09;

public class Cat_R {
	private String name;
	
	public Cat_R breed() {
		return new Cat_R();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
}
