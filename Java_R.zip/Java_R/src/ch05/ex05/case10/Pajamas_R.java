package ch05.ex05.case10;

public class Pajamas_R {

}
