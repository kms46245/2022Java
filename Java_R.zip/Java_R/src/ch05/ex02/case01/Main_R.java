package ch05.ex02.case01;

public class Main_R {
	public static void main(String[] args) {
		Box_R box = new Box_R();
		
		box.setA(1);
		box.setB(2);
		
		int result = box.getA() + box.getB();
		System.out.println(result);

		result = box.getA() - box.getB();
		System.out.println(result);
	}
}
