package ch05.ex02.case01;

public class Box_R {
	private int a;
	private int b;
	
	public int getA() {
		return a;
	}
	
	public int getB() {
		return b;
	}
	
	public void setA(int a) {
		this.a = a;
	}
	
	public void setB(int b) {
		this.b = b;
	}	
}
