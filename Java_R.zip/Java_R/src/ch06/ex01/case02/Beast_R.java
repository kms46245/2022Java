package ch06.ex01.case02;

public class Beast_R {
	public void run() {
		
	}
}
