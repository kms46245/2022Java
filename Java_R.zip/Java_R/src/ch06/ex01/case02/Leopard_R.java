package ch06.ex01.case02;

public class Leopard_R extends Beast_R{

}
