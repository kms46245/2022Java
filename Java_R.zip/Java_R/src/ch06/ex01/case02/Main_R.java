package ch06.ex01.case02;

public class Main_R {
	public static void main(String[] args) {
		Leopard_R leopard = new Leopard_R();
		Lion_R lion = new Lion_R();
		
		leopard.run();
		lion.run();
	}
}
