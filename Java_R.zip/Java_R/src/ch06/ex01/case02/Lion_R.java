package ch06.ex01.case02;

public class Lion_R extends Beast_R{

}
