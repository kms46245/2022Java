package ch06.ex01.case01;

public class Lion_R {
	public void run() {}
}
