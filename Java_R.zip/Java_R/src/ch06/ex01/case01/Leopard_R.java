package ch06.ex01.case01;

public class Leopard_R {
	public void run() {}
}
