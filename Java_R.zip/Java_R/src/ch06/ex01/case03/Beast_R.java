package ch06.ex01.case03;

public class Beast_R {
	public void run() {	}
}
