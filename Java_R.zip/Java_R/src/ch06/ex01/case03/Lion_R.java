package ch06.ex01.case03;

public class Lion_R extends Beast_R{
	public void shout() {}
}
