package ch06.ex04.case01;

public class Animal_R {
	private String name;
	
	public Animal_R(String name) {
		this.name = name;
	}
	
	public String getName() {
		return this.name;		
	}
}
