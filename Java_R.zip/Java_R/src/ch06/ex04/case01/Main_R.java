package ch06.ex04.case01;

public class Main_R {
	public static void main(String[] args) {
		Cat_R cat = new Cat_R("���ڹ�", 3);
		
		cat = new Cat_R(null, 0);
		
		System.out.println(cat.getName() + ", " + cat.getAge());
	}
}
