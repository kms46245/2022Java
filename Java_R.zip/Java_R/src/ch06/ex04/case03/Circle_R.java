package ch06.ex04.case03;

public class Circle_R extends Point_R{
	private int r;
	
	public Circle_R(int x, int y, int r) {
		super(x, y);
		this.r = r;
	}
	
	@Override
	public String toString(){
		return String.format("(%d, %d), %d", this.getX(),this.getY(),r);
	}
}
