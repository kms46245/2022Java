package ch06.ex04.case03;

public class Main_R {
	public static void main(String[] args) {
		Circle_R circle = new Circle_R(1, 2, 3);
		
		System.out.println(circle);
	}
}
