package ch06.ex06.case09;

public class Chrome extends Browser{
	
}
