package ch06.ex06.case04;

public class Main {
	public static void main(String[] args) {
		
	}
}
