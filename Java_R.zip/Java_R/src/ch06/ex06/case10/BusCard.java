package ch06.ex06.case10;

public interface BusCard {
	 void tagOn();
	 void tagOff();
}
