package ch06.ex06.case03;

public interface Appliance {
	void on();
	void off();
}
