package ch06.ex06.case07;

public interface Code {
	int USER_ADD = 1; // �ڵ�� / �ڵ尪
	int USER_DEL = 2;
}
