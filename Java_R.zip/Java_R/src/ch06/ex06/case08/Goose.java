package ch06.ex06.case08;

public class Goose implements Animal{
	@Override
	public void move() {
		System.out.println("���ư���.");
	}
}
