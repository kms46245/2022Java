package ch06.ex06.case01;

public class Main {
	public static void main(String[] args) {
		// Appliance app = new Appliance();
	}
}
