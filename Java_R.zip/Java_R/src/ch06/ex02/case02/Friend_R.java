package ch06.ex02.case02;

public class Friend_R {
	public void Play() {
	Parent_R parent = new Parent_R();
	
	//parent.getRegNum();		// private
	parent.getName();			// public
	parent.getMoney();			// protected
	parent.addMoney(1000);		// default

	}
}
