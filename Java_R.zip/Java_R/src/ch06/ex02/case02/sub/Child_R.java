package ch06.ex02.case02.sub;

import ch06.ex02.case02.Parent_R;

public class Child_R extends Parent_R {
	public void play() {
		//this.getRegNum; 			//private
		this.getName();				//public
		this.getMoney();			//protected
		//this.addMoney(1000);		//default
	}

}
