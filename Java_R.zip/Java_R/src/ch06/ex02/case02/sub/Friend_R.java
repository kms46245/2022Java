package ch06.ex02.case02.sub;

import ch06.ex02.case02.Parent_R;

public class Friend_R {
	public void play() {
		Parent_R parent = new Parent_R();
		
		//parent.getRegNum();		// private
		parent.getName();			// public
		//parent.getMoney();		// protected
		//parent.addMoney(1000);	// default
	}
}
