package ch06.ex02.case01;

public class A {
	private int a;
	int b;			//default
	protected int c;
	public int d;
	
	private void m1() {}		// method�� �����ȴ�.
	void m2() {}
	protected void m3() {}
	public void m4() {}			
}
// access identifier