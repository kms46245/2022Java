package ch06.home.ex03.case02;

public class Actor extends Man{
	@Override
	public void Perform() {
		System.out.println("���⸦ �Ѵ�.");
	}
}
