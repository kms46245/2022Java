package ch06.home.ex03.case02;

public class Singer extends Man{
	@Override
	public void Perform() {
		System.out.println("�뷡�� �Ѵ�.");
	}
}
