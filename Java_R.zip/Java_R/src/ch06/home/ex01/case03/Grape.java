package ch06.home.ex01.case03;

public class Grape extends Fruit {
	
}
