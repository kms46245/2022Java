package ch06.ex05.case02;

public class Animal_R {
	private int age;
	
	public Animal_R(int age) {
		this.age = 1000 * age;
	}
	
	public void shout() {
		System.out.println("����.");
	}
	
	public int getAge() {
		return this.age;
	}
}
