package ch06.ex05.case02;

public class Dog_R extends Animal_R{
	private int age;
	
	public Dog_R(int age) {
		super(age);
		this.age = age;
	}
	
	@Override
	public int getAge() {
		return this.age;
	}
}
