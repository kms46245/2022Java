package ch06.ex05.case01;

public class Product_R {
	private int price;
	
	public Product_R(int price) {
		this.price =price * 2;
	}
	
	public int getPrice() {
		return this.price;
	}
}
