package ch06.ex05.case01;

public class Main_R {
	public static void main(String[] args) {
		Shoes_R shoes = new Shoes_R(1000);
		
		System.out.println(shoes.getPrice());
	}
}
