package ch06.ex03.case01;

public class Cat_R extends Animal_R{
	
}
