package ch06.ex03.case01;

public class Dog_R extends Animal_R{
	
}
