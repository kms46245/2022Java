package ch06.ex03.case01;

public class Main_R {
	public static void main(String[] args) {
		Cat_R cat = new Cat_R();
		Dog_R dog = new Dog_R();
		
		cat.Shout();
		dog.Shout();
	}
}
