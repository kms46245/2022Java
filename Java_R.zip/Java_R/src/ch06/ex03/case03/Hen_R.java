package ch06.ex03.case03;

public class Hen_R {

}
