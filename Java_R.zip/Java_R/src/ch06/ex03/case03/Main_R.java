package ch06.ex03.case03;

public class Main_R {
	public static void main(String[] args) {
		Duck_R duck = new Duck_R();
		Hen_R hen = new Hen_R();
		
		System.out.println(duck);
		System.out.println(hen);
	}
}
