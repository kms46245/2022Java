package ch06.ex03.case02;

public class Dog_R extends Animal_R{
	@Override
	public void shout() {
		System.out.println("�۸�");
	}

}
