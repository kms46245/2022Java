package ch08.ex02.case01;

public class Main_R {
	public static void main(String[] args) {
		Day_R day = Day_R.TUESDAY;
		
		String dayName = "";
		switch(day) {
		case MONDAY: dayName = "������"; break;
		case TUESDAY: dayName = "ȭ����";
		}
		
		System.out.println(dayName);
	}
}
