package ch08.ex02.case02;

import java.util.Arrays;
import java.util.List;

public class Main_R {
	public static void main(String[] args) {
		User_R user1 = new User_R("���Ѽ�", Level_R.COPPER);
		User_R user2 = new User_R("�ѾƸ�", Level_R.SILVER);
		User_R user3 = new User_R("�����", Level_R.GOLD);
		
		List<User_R> users = Arrays.asList(user1, user2, user3);
		
		users.forEach(user -> {
			try {
				user.upgradeLevel();
			}catch(IllegalStateException e) {}
		});
		
		System.out.println(users);
	}
}
