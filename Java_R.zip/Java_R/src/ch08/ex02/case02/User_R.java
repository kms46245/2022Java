package ch08.ex02.case02;

public class User_R {
	private String name;
	private Level_R level;
	
	public User_R(String name, Level_R level) {
		this.name = name;
		this.level = level;
	}
	
	public void upgradeLevel() {
		Level_R nextLevel = level.next();
		if(nextLevel == null)
			throw new IllegalStateException(
					"�̹� �ְ� ���" + this.level + "�Դϴ�.");
	
		this.level = nextLevel;
	}
	
	@Override
	public String toString() {
		return String.format("%s %s", name, level);
	}
}
