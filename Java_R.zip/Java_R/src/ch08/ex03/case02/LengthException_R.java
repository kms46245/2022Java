package ch08.ex03.case02;

public class LengthException_R extends Exception{
	public LengthException_R(String msg) {
		super(msg);
	}
}
