package ch08.ex03.case02;

public class NumberException_R extends RuntimeException{
	public NumberException_R(String msg) {
		super(msg);
	}
}
