package ch02.home.ex01;

public class H01Replacement_R {

	public static void main(String[] args) {
		
		int i = 156;
		int j = 239;
		int tmp;
		
		System.out.printf("A = %d\nB = %d\n", i,j);
		
		tmp = i;
		i = j;
		j = tmp;
		
		System.out.printf("A = %d\nB = %d\n", i,j);
				
	}

}
