package ch02.home.ex01;

import java.util.Scanner;

public class H02Replacement_R {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		System.out.print("A�� �� �Է�\n>");
		int i = scan.nextInt();
		System.out.print("B�� �� �Է�\n>");
		int j = scan.nextInt();
		
		System.out.printf("A : %d\nB : %d\n", i , j);
		
		int tmp;
		tmp = i;
		i = j;
		j = tmp;
		
		System.out.println("A�� B�� ���� ��ü�մϴ�.");
		System.out.printf("A : %d\nB : %d\n", i ,j);
		
	}

}
