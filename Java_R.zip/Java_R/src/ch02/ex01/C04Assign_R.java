package ch02.ex01;

public class C04Assign_R {
	public static void main(String[] args) {
		int i = 10;
		int j = 20;
		System.out.printf("%d, %d\n",i , j);
		
		i = j;
		System.out.printf("%d, %d\n",i , j);
		
		i = j = 30;
		System.out.printf("%d, %d\n",i , j);
		
		double d = Math.random();
		System.out.printf("%.3f", d);

	}
}
