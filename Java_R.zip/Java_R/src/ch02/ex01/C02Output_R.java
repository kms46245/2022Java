package ch02.ex01;

public class C02Output_R {
	public static void main(String[] args) {
		int score = 100;
		System.out.println(100);
		System.out.println(score);
		System.out.println(100 + 1);
		System.out.println(Math.random());
		
		System.out.print(200);
		System.out.print("\s");
		System.out.print(300);
		System.out.println(400);
		System.out.print("\n");
	
		System.out.printf("%b %c %d %f %s\n", false, 'b', 15, 1.23, "good");
		System.out.printf("%b/%c/%d/%f/%s\n", false, 'b', 15, 1.23, "good");
		System.out.printf("%3b|%-3c|%3d|%3.4f|%3s\n", false, 'b', 15,  1.23, "good");
		System.out.printf("%3b|%-3c|%3d|%.4f|%3s\n", false, 'b', 15,  1.23, "good");
		
		String name = "��μ�";
		int age = 29;
		String gender = "Male";
		System.out.printf("%s %d %s\n", name,age,gender);
		System.out.printf("%s�� %d���̰� ������ %s�ϴ�.\n", name,age,gender);
		System.out.println(name + "�� " + age + "���̰� ������ " + gender + "�Դϴ�.\n");
	}
}
