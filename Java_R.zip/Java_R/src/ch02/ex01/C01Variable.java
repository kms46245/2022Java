package ch02.ex01;

public class C01Variable {
	
	
	public static void main(String[] args) {
		boolean bl = false;
		bl = true;
		byte b = 0;
		short s = 0;
		char c = 0;
		int i = 0;
		long l = 0L;
		
		i += 1;
		i *= 4;
		i /= 2;
		i %= 2;
		i -= -3;
		
		String str = "";
		
		int a;
		a = 0;
		// int a;
		
		// int x;
		// int y;
		int x,y;
		int x2=0, y2=0;
	}	
}
