package ch02.ex02;

import java.time.LocalDate;
import java.time.LocalTime;

public class C06_08Date_R {
	public static void main(String[] args) {
		LocalDate date = LocalDate.now();
		LocalTime time = LocalTime.now();
		
		System.out.println(date);
		System.out.println(time);
		
		
		LocalDate date2 = LocalDate.of(2022, 11, 8);
		LocalTime time2 = LocalTime.of(16, 24, 31);
		
		System.out.println(date2);
		System.out.println(time2);
		
		date = date.plusDays(1);
		date2 = date2.minusDays(1);
		
		System.out.println("���� : " + date);
		System.out.println("date2�� ���� : " + date2);
		
	}
}
