package ch02.ex03;

public class C02DoubleInt_R {
	public static void main(String[] args) {
		double d = 1.42;
		double d2 = 1.63;
		
		int i = (int)d;
		System.out.printf("%d, %.2f\n", i ,d);
		
		double f = Math.floor(d);	// ����
		double r = Math.round(d);	// �ݿø�
		double r2 = Math.round(d2); // ''
		
		System.out.printf("%.2f, %.2f, %.2f", f, r, r2);
	}
}
