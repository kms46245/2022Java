package ch02.ex03;

public class C01IntDouble_R {
	public static void main(String[] args) {
		int i = 1;
		double d = 0.0;
		
		d = i;	// promotion(int�� double�� ������ ���� ����)
		System.out.printf("%.2f, %d\n", d, i);
		
		d = (double)i;
		System.out.printf("%.2f, %d\n", d, i);
		
		i = (int)d; // i = d; >> type mismatch
		System.out.printf("%.2f, %d\n", d, i);
	}
}
