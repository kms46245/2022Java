package ch03.ex01;

public class C01_02PPMM_R {
	public static void main(String[] args) {
		int i = 0;
		++i;
		System.out.println(i);
		i++;
		System.out.println(i);
		
		int i2 = 0;
		--i2;
		System.out.println(i2);
		i2--;
		System.out.println(i2);
		
		i = 0;
		int j = ++i; // ��������
		System.out.printf("i : %d, j : %d\n", i , j);
		
		i = 0;
		j = i++; // ��������
		System.out.printf("i : %d, j : %d\n", i , j);
		
		i2 = 0;
		int j2 = --i;	// ��������
		System.out.printf("i : %d, j : %d\n", i2 , j2);
		
		i2 = 0;
		j = i2--; // ��������
		System.out.printf("i : %d, j : %d\n", i2 , j2);
		
	}
}
