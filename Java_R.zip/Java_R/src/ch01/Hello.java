package ch01;

public class Hello {
	public static void main(String[] args) {
		
	}
}