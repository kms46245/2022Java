package Practice.C02Calculator;

public class CalculatorRun {
	public static void main(String[] args) {
		Calculator runCalc = new Calculator();
		runCalc.execute();
	}
}
