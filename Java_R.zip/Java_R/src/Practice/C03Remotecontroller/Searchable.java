package Practice.C03Remotecontroller;

public interface Searchable {
	void search(String url);
}
