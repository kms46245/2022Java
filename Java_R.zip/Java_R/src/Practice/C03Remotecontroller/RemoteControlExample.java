package Practice.C03Remotecontroller;

public class RemoteControlExample {
	public static void main(String[] args) {
		RemoteControl rc = null;
		
		RemoteControl.changeBattery();	// static
		
		rc = new Television();
		
		rc.turnOn();
		rc.setMute(true);				// default
		
		rc = new Audio();
		
		rc.turnOn();
		rc.setMute(true);		
		}
}

